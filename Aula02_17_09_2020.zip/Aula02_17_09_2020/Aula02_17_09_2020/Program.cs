﻿using System;

namespace Aula02_17_09_2020
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Vai curintia!!!");
            Console.WriteLine("Palmeiras não tem mundial!!!");
            Console.WriteLine("São Paulo não tem Copa do Brasil!!!");
            Console.Write("Santos é o Santos!!!");
        }
    }
}
